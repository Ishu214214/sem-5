public class eg {
    public static void main(String[] args)
    {
    
        double now = System.currentTimeMillis();
        eg demo = new eg();


        System.out.println(demo.findsum(999));
        System.out.println(System.currentTimeMillis() -now);
    }

    public int findsum(int n)
    {

        return n*(n+1)/2;
    }




}
