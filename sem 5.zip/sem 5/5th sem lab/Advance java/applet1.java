import java.awt.*;
import java.applet.*;
public class applet1 extends Applet
{
String msg="";
public void init()
{
msg="This is first applet program";
}

public void start()
{
msg=msg+",it is client side program";
}

public void paint(Graphics g)

{
g.drawString(msg,40,60);
}

}

/*
<applet code="applet1" width=300 height=400>;
</applet>;
*/